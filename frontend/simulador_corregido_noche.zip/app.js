
const paramInputs = {
  binomial: [
    { id: "n", label: "Número de ensayos (n)", type: "number", value: 10 },
    { id: "p", label: "Probabilidad de éxito (p)", type: "number", value: 0.5 }
  ],
  exponential: [
    { id: "scale", label: "Escala (1/λ)", type: "number", value: 1.0 }
  ],
  poisson: [
    { id: "lam", label: "Lambda (λ)", type: "number", value: 4.0 }
  ],
  bernoulli: [
    { id: "p", label: "Probabilidad de éxito (p)", type: "number", value: 0.5 }
  ],
  multinomial: [
    { id: "n", label: "Número total de ensayos (n)", type: "number", value: 10 },
    { id: "pvals", label: "Probabilidades separadas por coma", type: "text", value: "0.2,0.3,0.5" }
  ],
  geometric: [
    { id: "p", label: "Probabilidad de éxito (p)", type: "number", value: 0.5 }
  ],
  hypergeometric: [
    { id: "ngood", label: "Elementos buenos (ngood)", type: "number", value: 10 },
    { id: "nbad", label: "Elementos malos (nbad)", type: "number", value: 5 },
    { id: "nsample", label: "Tamaño de muestra", type: "number", value: 5 }
  ],
  uniform: [
    { id: "low", label: "Límite inferior", type: "number", value: 0 },
    { id: "high", label: "Límite superior", type: "number", value: 10 }
  ]
};

const distDescriptions = {
  binomial: `🔹 <strong>Distribución Binomial</strong><br>
La distribución binomial describe el número de éxitos en una secuencia de n ensayos independientes de tipo sí/no, cada uno con una probabilidad fija p de éxito.<br>
Fue desarrollada por <strong>Jacob Bernoulli</strong> en el siglo XVII.`,
  exponential: `🔹 <strong>Distribución Exponencial</strong><br>
Modela el tiempo entre eventos en un proceso de Poisson.`,
  poisson: `🔹 <strong>Distribución de Poisson</strong><br>
Modela el número de eventos que ocurren en un intervalo fijo.`,
  bernoulli: `🔹 <strong>Distribución de Bernoulli</strong><br>
Representa un experimento con dos resultados posibles: éxito o fracaso.`,
  multinomial: `🔹 <strong>Distribución Multinomial</strong><br>
Generaliza la binomial para más de dos categorías.`,
  geometric: `🔹 <strong>Distribución Geométrica</strong><br>
Modela el número de ensayos hasta el primer éxito.`,
  hypergeometric: `🔹 <strong>Distribución Hipergeométrica</strong><br>
Muestreo sin reemplazo en poblaciones finitas.`,
  uniform: `🔹 <strong>Distribución Uniforme</strong><br>
Todos los valores dentro del intervalo tienen la misma probabilidad.`
};

let chart, curveChart;

window.addEventListener("DOMContentLoaded", () => {
  updateParams();
  document.getElementById("modeToggle").addEventListener("click", () => {
    document.getElementById("body").classList.toggle("dark-mode");
  });
  document.getElementById("distribution").addEventListener("change", updateParams);
});

function updateParams() {
  const dist = document.getElementById("distribution").value;
  document.getElementById("description").innerHTML = distDescriptions[dist] || "";
  const paramDiv = document.getElementById("parameters");
  paramDiv.innerHTML = "";
  paramInputs[dist].forEach(input => {
    const wrapper = document.createElement("div");
    wrapper.className = "mb-3";
    const label = document.createElement("label");
    label.className = "form-label";
    label.htmlFor = input.id;
    label.innerText = input.label;
    const field = document.createElement("input");
    field.className = "form-control";
    field.type = input.type;
    field.id = input.id;
    field.value = input.value;
    wrapper.appendChild(label);
    wrapper.appendChild(field);
    paramDiv.appendChild(wrapper);
  });
}

async function generate() {
  const dist = document.getElementById("distribution").value;
  const size = parseInt(document.getElementById("size").value);
  const params = {};
  paramInputs[dist].forEach(input => {
    const value = document.getElementById(input.id).value;
    params[input.id] = (input.id === "pvals")
      ? value.split(',').map(Number)
      : parseFloat(value);
  });

  const response = await fetch("http://localhost:8000/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: dist, params, size })
  });

  const data = await response.json();
  const values = data.values.flat();

  const counts = values.reduce((acc, val) => {
    acc[val] = (acc[val] || 0) + 1;
    return acc;
  }, {});

  const labels = Object.keys(counts).sort((a, b) => a - b);
  const freqs = labels.map(l => counts[l]);

  if (chart) chart.destroy();
  const ctx = document.getElementById("chart").getContext("2d");
  chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: `Frecuencia`,
        data: freqs,
        backgroundColor: "rgba(54, 162, 235, 0.6)"
      }]
    },
    options: {
      responsive: true,
      scales: {
        x: { title: { display: true, text: "Valores" } },
        y: { title: { display: true, text: "Frecuencia" } }
      }
    }
  });

  if (curveChart) curveChart.destroy();
  const allValues = values.map(Number).sort((a, b) => a - b);
  const min = Math.min(...allValues);
  const max = Math.max(...allValues);
  const bins = 50;
  const step = (max - min) / bins;
  const density = [];
  const x_vals = [];

  for (let i = 0; i <= bins; i++) {
    const x = min + i * step;
    x_vals.push(x);
    let sum = 0;
    for (const v of allValues) {
      const u = (x - v) / step;
      sum += Math.exp(-0.5 * u * u);
    }
    density.push(sum / (allValues.length * Math.sqrt(2 * Math.PI)));
  }

  const curveCtx = document.getElementById("curveChart").getContext("2d");
  curveChart = new Chart(curveCtx, {
    type: "line",
    data: {
      labels: x_vals,
      datasets: [{
        label: "Curva suavizada (KDE)",
        data: density,
        borderColor: "black",
        borderWidth: 2,
        fill: false,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      scales: {
        x: { title: { display: true, text: "x" } },
        y: { title: { display: true, text: "Densidad" } }
      }
    }
  });
}
